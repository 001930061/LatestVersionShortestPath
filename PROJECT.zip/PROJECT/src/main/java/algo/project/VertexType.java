package algo.project;

// Enum representing the type of vertex
public enum VertexType {
    PICKUP,

    DROPOFF,

    NORMAL,

    GARAGE;
}